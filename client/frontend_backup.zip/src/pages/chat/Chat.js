import React, { useEffect, useRef, useContext, useState } from "react";
import { useSubscription, useMutation, gql, useQuery } from "@apollo/client";
import { AuthContext } from "../../context/auth";
import { animateScroll } from "react-scroll";
import { Input, Button, Transition, Modal, Header } from "semantic-ui-react";
import isContentValid from "../../util/ChatValidations";
import { ErrorBoundary } from "react-error-boundary";
import { openSuccessSnack } from "../../components/SnackBar";
import { GET_CHAT_REQUESTS } from "./ChatLobby";
import ErrorFallBackPage from "../ErrorFallBack";
import { useHistory } from "react-router-dom";
import MenuBar from "../../components/MenuBar";
import "./Chat.css";
const GET_MESSAGES_INIT = gql`
  query Message($receiver: String!, $other: String!) {
    messages(receiver: $receiver, other: $other) {
      id
      content
      user
    }
  }
`;

const GET_MESSAGES = gql`
  subscription($receiver: String!, $other: String!) {
    messages(receiver: $receiver, other: $other) {
      id
      content
      user
    }
  }
`;

const POST_MESSAGE = gql`
  mutation($user: String!, $receiver: String!, $content: String!) {
    postMessage(user: $user, receiver: $receiver, content: $content)
  }
`;
const EXIT_CHAT = gql`
  mutation {
    exitChat
  }
`;

function RulesModal() {
  const [open, setOpen] = useState(true);
  return (
    <Modal
      onClose={() => setOpen(false)}
      onOpen={() => setOpen(true)}
      open={open}
    >
      <Modal.Header>
        <p className="modal-text">قوانین چت</p>
      </Modal.Header>
      <Modal.Content>
        <Modal.Description>
          <Header>
            <p className="modal-text">
              با عرض تشکّر از همکاری شما، برای گرفتن امتیاز گفت‌و‌گوی شما باید
              در چهارچوب زیر قرار گیرد:
            </p>
          </Header>
          <p className="modal-text">
            ۱. فرض کنید دانشجو هستید، با دوستانتان گپ بزنید!
          </p>
          <p className="modal-text">۲. حاوی کلمات نامناسب نباشد.</p>
          <p className="modal-text">
            ۳.هر پیام حدّاقل ۳ کلمه و حدّاکثر ۲۵ کلمه باشد.
          </p>
          <p className="modal-text">۴.متنوع و با معنی باشد</p>
          <p className="modal-text">۵. فارسی باشد (اصطلاحاً فینگلیش نباشد).</p>
          <p className="modal-text b">
            ۶. حدّاقل ۴ پیام از طرف شما در آن موجود باشد.
          </p>
          <p className="modal-text">
            ۷. پیام‌های شما و مخاطبتان یکی در میان باشد.
          </p>
        </Modal.Description>
      </Modal.Content>
      <Modal.Actions>
        <Button
          content="باشد"
          labelPosition="right"
          icon="checkmark"
          color="blue"
          onClick={() => {
            setOpen(false);
          }}
          className="modal-button"
          primary
        />
      </Modal.Actions>
    </Modal>
  );
}
const Messages = ({ user, other, data, initQuery }) => {
  if (!data && !initQuery.data) {
    return null;
  }
  const activeData =
    data && data.messages && data.messages.length > 0 ? data : initQuery.data;
  animateScroll.scrollToBottom({
    containerId: "ContainerElementID",
  });
  return activeData ? (
    <div className="chat" id="ContainerElementID">
      {activeData.messages.map(({ id, user: messageUser, content }) => (
        <div class="message-row">
          <div
            class={
              "message message--" + (user === messageUser ? "sent" : "recieved")
            }
          >
            <div class="message-avatar">
              {user === messageUser ? "شما" : "مخاطب"}
            </div>
            <div class="message-bubble">
              <p className="message-text rtl-form-field ">{content}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  ) : (
    <div class="loading">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
    </div>
  );
};
const Chat = ({ otherUser }) => {
  const [postMessage] = useMutation(POST_MESSAGE);
  const history = useHistory();
  const [exitChat] = useMutation(EXIT_CHAT);

  const other = otherUser.location.state
    ? otherUser.location.state.otherUser
    : "";
  let { user } = useContext(AuthContext);
  if (!user) user = { username: "" };
  const [state, stateSet] = React.useState({
    user: user.username,
    receiver: other,
    content: "",
  });
  const { data, loading } = useSubscription(GET_MESSAGES, {
    variables: { receiver: user.username, other: other },
    fetchPolicy: "network-only",
  });
  const initQuery = useQuery(GET_MESSAGES_INIT, {
    variables: { receiver: user.username, other: other },
    fetchPolicy: "network-only",
  });

  const onSend = () => {
    const activeData =
      data && data.messages && data.messages.length > 0 ? data : initQuery.data;
    if (
      activeData.messages.length > 0 &&
      activeData.messages[activeData.messages.length - 1].user === user.username
    ) {
      setChatError("نوبت ارسال پیام شما نرسیده است");
      return;
    }
    if (user.username === "") history.push("/chatlobby");
    const error = isContentValid(state.content);
    if (!error) {
      postMessage({
        variables: state,
      });
    } else {
      setChatError(error);
    }
    stateSet({
      ...state,
      content: "",
    });
  };
  const [chatError, setChatError] = React.useState(null);
  const requestsSub = useSubscription(GET_CHAT_REQUESTS, {
    variables: { receiver: user.username },
  });
  const openSnackAsync = async (text) => {
    openSuccessSnack(text);
  };
  if (
    requestsSub?.data?.chatRequestSub &&
    requestsSub.data.chatRequestSub !== ""
  ) {
    openSnackAsync("پیام جدید دارید");
  }
  if (other === "") history.push("/chatlobby");
  if (initQuery.loading)
    return (
      <>
        <MenuBar />
        <div class="loading">
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
        </div>
      </>
    );
  else
    return (
      <>
        <RulesModal />
        <MenuBar />
        <div>
          <div className="chat-header">
            <div className="chat-header-username">مخاطب: {state.receiver}</div>
          </div>
          <Messages
            user={state.user}
            other={state.receiver}
            initQuery={initQuery}
            data={data}
          />

          <footer className="chat-footer">
            <Input
              className="chat-input rtl-form-field"
              placeholder="چیزی بگو..."
              value={state.content}
              onChange={(evt) =>
                stateSet({
                  ...state,
                  content: evt.target.value,
                })
              }
              onKeyUp={(evt) => {
                if (evt.keyCode === 13) {
                  onSend();
                }
              }}
            />
            <div>
              <Button className="form-field" primary onClick={() => onSend()}>
                ارسال
              </Button>
            </div>
          </footer>
          <div className="chat-error">{chatError}</div>
        </div>
      </>
    );
};

export default Chat;
