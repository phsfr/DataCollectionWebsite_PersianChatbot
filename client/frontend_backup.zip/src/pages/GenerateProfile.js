import { readFileSync } from 'fs';

function getRandom(filename){//, cb) {
    var random_elem = "not set"
    var allElems =  readFileSync(filename, 'utf8', function(error, data) {
        if (error){ console.log(JSON.stringify(error)); }
        //var jobList = data.split(/\r?\n/);
        //cb(jobList[Math.floor(Math.random()*jobList.length)]);
    })
    var allElemsList = allElems.split(/\r?\n/);
    return allElemsList[Math.floor(Math.random()*allElemsList.length)];
}
//console.log(getRandom('../profileLists/jobList.txt'))//, function(data) { return data} ))
//elem = await getRandom('../profileLists/jobList.txt'))
//console.log(getRandom('../profileLists/jobList.txt'))
function getProfile(){
    let gender ,name 
    if(Math.random() < 0.5){
        gender = "female"
        name = getRandom('../profileLists/femaleNameList.txt')
    }else{
        gender = 'male'
        name = getRandom('../profileLists/maleNameList.txt')
    }
    var job = getRandom('../profileLists/jobList.txt')
    var hobby = getRandom('../profileLists/hobbiesList.txt')
    var resistance = getRandom('../profileLists/resistanceList.txt')
    //console.log(job)
    //console.log(hobby)
    return {'name': name, 'gender': gender, 'job': job, 'hobby': hobby, 'resistance': resistance};
};

console.log(getProfile())

