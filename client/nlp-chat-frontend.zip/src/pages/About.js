function About() {
  return <h2>درباره‌ی ما</h2>
}

export default About
